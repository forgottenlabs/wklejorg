#!/usr/bin/env python

""" Simple wklej.org paste script
license: gplv2

version 0.1.0
"""


import sys
import commands
import xmlrpclib

syntaxes = [ 
'apache', 'bash', 'bat', 'c', 'cpp', 'csharp', 'css', 'd', 'diff',
'dylan', 'erlang', 'gas', 'haskell', 'html', 'html+django', 'html+genshi', 'html+mako', 'html+myghty',
'html+php', 'irb', 'irc', 'java', 'js', 'jsp', 'lua', 'minid', 'ocaml', 'perl', 'pycon', 'pytb', 'python',
'rhtml', 'rst', 'ruby', 'scheme', 'smarty', 'sourceslist', 'sql', 'squidconf', 'tex', 'text', 'vim', 'xml'

]

def getTresc(input):
    if input:
        tresc = input
    else:
        print "Input is empty!"
        sys.exit(1)
    return tresc

def getSyntax(argument):
    if argument:
        syntax = argument
    else:
        syntax = 'text'
    return syntax	

def getAutor():
    try:
        autor = commands.getoutput('whoami')
    except:
        autor = 'Anonim'
    return autor


def main(args=sys.argv):

    if len(args) <= 1:

        print """
Usage:

To list available syntaxes do:
$ wklej help

To paste something: 
$ echo 'something' | wklej syntax
$ cat file | wklej syntax
$ wklej syntax

"""
        sys.exit(1)
    
    elif sys.argv[1] == 'help':
        print "Allowed syntaxes are:" 
        for item in syntaxes: 
            print item
        sys.exit(1)

    else: 

        tresc = getTresc(sys.stdin.read())
        syntax = getSyntax(args[1])

        if syntax in syntaxes:
          pass
        else:
            print "WRONG SYNTAX"
            sys.exit(1)

        autor = getAutor()

        rpc_srv = xmlrpclib.ServerProxy("http://wklej.org/xmlrpc/")
        result = rpc_srv.dodaj_wpis(tresc, syntax, autor)
        print "http://wklej.org%s" % result

        sys.exit(0)

if __name__=='__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
